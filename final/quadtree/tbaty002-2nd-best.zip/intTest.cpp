#include <iostream>

using namespace std;

int main()
{
    cout << "testing integer division" << endl;

    int test = 695;
    cout << "in half: " << test / 2 << " " << test * .50 << endl;
    cout << "x1.5: " << test * 1.5 << " " << test * 3 / 2 << endl;
    return 0;
}
